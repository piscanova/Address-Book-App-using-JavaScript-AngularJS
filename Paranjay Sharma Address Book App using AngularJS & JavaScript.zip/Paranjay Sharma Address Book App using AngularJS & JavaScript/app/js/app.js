(function() {
    "use strict";

    angular.module('contactApp', ['file-data-url', 'ngRoute', 'LocalStorageModule', 'ngMap'])
        .config(function($routeProvider, $locationProvider) {
            $routeProvider.when('/', {
                templateUrl: 'views/contactList.html',
                controller: 'contactListController'
            }).when('/contact', {
                templateUrl: 'views/contact.html',
                controller: 'contactController'
            }).when('/contact/:id', {
                templateUrl: 'views/contact.html',
                controller: 'contactController'
            });
            $locationProvider.html5Mode(false);
            $locationProvider.hashPrefix('!');
        })
        .config(function (localStorageServiceProvider) {
            localStorageServiceProvider
                .setPrefix('08724.hw5');
        })
        .controller('contactListController', function($scope, localStorageService, $location) {

        $scope.submittedAddresses = [];
        $scope.address = {};
        for(var item in localStorage) {
            var newItem = JSON.parse(localStorage[item]);
            $scope.submittedAddresses.push(newItem);

        }


        $scope.removeAddress = function(index) {
            localStorageService.remove(index);
            console.log("Value of parameter removed: " + index);
            //$scope.submittedAddresses.splice(index, 1);
            for(var i = 0; i < $scope.submittedAddresses.length; i++) {
              if($scope.submittedAddresses[i].email == index) {
              $scope.submittedAddresses.splice(i, 1);
              break;
             }
          }

        };
        $scope.redirect = function(){
           window.location = "/#!/contact";
          };
          $scope.editContact = function(value){
           window.location = "/#!/contact/" + value;
          }



        })
        .controller('contactController', function($scope, localStorageService, $routeParams, $location) {

            var usStates = {
        AL: "ALABAMA",AK: "ALASKA",AS: "AMERICAN SAMOA",AZ: "ARIZONA",AR: "ARKANSAS",CA: "CALIFORNIA",CO: "COLORADO",
        CT: "CONNECTICUT",DE: "DELAWARE",DC: "DISTRICT OF COLUMBIA",FM: "FEDERATED STATES OF MICRONESIA",FL: "FLORIDA",
        GA: "GEORGIA",GU: "GUAM",HI: "HAWAII",ID: "IDAHO",IL: "ILLINOIS",IN: "INDIANA",IA: "IOWA",KS: "KANSAS",KY: "KENTUCKY",
        LA: "LOUISIANA",ME: "MAINE",MH: "MARSHALL ISLANDS",MD: "MARYLAND",MA: "MASSACHUSETTS",MI: "MICHIGAN",MN: "MINNESOTA",
        MS: "MISSISSIPPI",MO: "MISSOURI",MT: "MONTANA",NE: "NEBRASKA",NV: "NEVADA",NH: "NEW HAMPSHIRE",NJ: "NEW JERSEY",
        NM: "NEW MEXICO",NY: "NEW YORK",NC: "NORTH CAROLINA",ND: "NORTH DAKOTA",MP: "NORTHERN MARIANA ISLANDS",OH: "OHIO",
        OK: "OKLAHOMA",OR: "OREGON",PW: "PALAU",PA: "PENNSYLVANIA",PR: "PUERTO RICO",RI: "RHODE ISLAND",SC: "SOUTH CAROLINA",
        SD: "SOUTH DAKOTA",TN: "TENNESSEE",TX: "TEXAS",UT: "UTAH",VT: "VERMONT",VI: "VIRGIN ISLANDS",VA: "VIRGINIA",
        WA: "WASHINGTON",WV: "WEST VIRGINIA",WI: "WISCONSIN",WY: "WYOMING"};

        $scope.stateOptions = usStates;
        $scope.files = [];
        $scope.address = {};
        
        
        if($routeParams.id != null) {
           var newInfo = localStorageService.get($routeParams.id);
           console.log("Value of injected parameter: " + $routeParams.id);
           $scope.address.firstName = newInfo.firstName;
           $scope.address.lastName = newInfo.lastName;
           $scope.address.email = newInfo.email;
           $scope.address.phone = newInfo.phone;
           $scope.address.addressOne = newInfo.addressOne;
           $scope.address.city = newInfo.city;
           $scope.address.state = newInfo.state;
           $scope.address.zip = newInfo.zip;
           $scope.address.photo = newInfo.photo;
        }
        

        $scope.submit = function() {
           
        $scope.storageType = 'Local storage';
        localStorageService.remove($routeParams.id);
        localStorageService.set($scope.address.email, $scope.address);
        window.location = "http://127.0.0.1:8000/#!/";

        };

        

        });


})();